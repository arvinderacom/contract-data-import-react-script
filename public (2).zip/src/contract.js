import { ethers } from 'ethers';
import contractABI from './contractABI.json'; // Import the ABI from a JSON file
import tokenABI from './tokenABI.json'; // Import the ABI from a JSON file

const contractAddress = '0x9c63af96b60fCA0eB8aA123EEBC8c74306De479b';

export const getContract = (signer) => {
  return new ethers.Contract(contractAddress, contractABI, signer);
};
export const getTokenContract = (contractAddress,signer) => {
  return new ethers.Contract(contractAddress, tokenABI, signer);
};
export default contractAddress;