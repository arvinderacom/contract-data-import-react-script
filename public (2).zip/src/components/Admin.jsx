// src/components/Admin.js
import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import { useWeb3 } from "../contexts/Web3Context";
import contractAddress, { getContract, getTokenContract } from "../contract";
import styled, { css } from "styled-components";
import ConnectWalletButton from "./ConnectWalletButton";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: ${({ theme }) => theme.colors.background};
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 10px;

  @media (max-width: ${({ theme }) => theme.breakpoints.tablet}) {
    padding: 15px;
  }

  @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
    padding: 10px;
  }
`;

const Section = styled.div`
  margin: 20px 0;
  width: 100%;

  h2 {
    margin-bottom: 10px;
    font-size: 1.2rem;
    color: ${({ theme }) => theme.colors.primary};
  }

  input {
    width: calc(100% - 22px);
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 1rem;

    @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
      padding: 8px;
      font-size: 0.9rem;
    }
  }

  button {
    width: 100%;
    padding: 10px;
    background-color: ${({ theme }) => theme.colors.primary};
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1rem;

    &:hover {
      background-color: ${({ theme }) => theme.colors.secondary};
    }

    @media (max-width: ${({ theme }) => theme.breakpoints.mobile}) {
      padding: 8px;
      font-size: 0.9rem;
    }

    ${(props) =>
    props.paused &&
    css`
        background-color: red;

        &:hover {
          background-color: darkred;
        }
      `}
  }
`;

const Admin = () => {
  const { signer } = useWeb3();
  const [transactionFee, setTransactionFee] = useState("");
  const [SwapCodeFee, setSwapCodeFee] = useState("");
  const [GweiFee, setGweiFee] = useState("");
  const [usdtAmount, setusdtAmount] = useState("");
  const [tokenAmount, settokenAmount] = useState("");
  const [opensource, setOpensource] = useState("");
  const [volumeLimit, setVolumeLimit] = useState("");
  const [transactionLimit, setTransactionLimit] = useState("");
  const [percentage, setPercentage] = useState("");
  const [whitelistUsers, setWhitelistUsers] = useState([]);
  const [dailyVolumes, setDailyVolumes] = useState([]);
  const [dailyTransactions, setDailyTransactions] = useState([]);
  const [dailyPercentages, setDailyPercentages] = useState([]);
  const [isPaused, setIsPaused] = useState(false);
  const [onyWhiteList, setonyWhiteList] = useState(false);
  const [owner, setOwner] = useState("")
  const [newOwner, setNewOwner] = useState("")
  const [removeAddress, setRemoveAddress] = useState("");
  const [removeAmount, setRemoveAmount] = useState("");
  const [tokenContract, setTokenContract] = useState("");
  const [tokenRemoveAmount, setTokenRemoveAmount] = useState("");
  useEffect(() => {
    const fetchTradingStatus = async () => {
      if (signer) {
        const contract = getContract(signer);
        const paused = await contract.Abstruct();
        console.log(paused);
        setIsPaused(paused);
      }
    };
    const fetchonyWhiteListStatus = async () => {
      if (signer) {
        const contract = getContract(signer);
        const paused = await contract.onyWhiteList();
        console.log(paused);
        setonyWhiteList(paused);
      }
    };
    const fetchOwner = async () => {
      if (signer) {
        const contract = getContract(signer);
        const Owner = await contract.Owner();
        console.log(Owner);
        setOwner(Owner);
      }
    };
    fetchOwner()
    fetchTradingStatus();
    fetchonyWhiteListStatus()
  }, [signer]);

  const handleAlternateEncryption = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.AlternateEncryption(ethers.utils.parseUnits(transactionFee, 0));
        alert("Transaction fee set successfully");
      }
    } catch (error) {
      alert(`Failed to set transaction fee: ${error.message}`);
    }
  };
  const handleSwapCode = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.AlternateEncryption(ethers.utils.parseUnits(SwapCodeFee, 0));
        alert("Transaction fee set successfully");
      }
    } catch (error) {
      alert(`Failed to set transaction fee: ${error.message}`);
    }
  };
  const handleGwei = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.Gwei(GweiFee);
        alert("Transaction fee set successfully");
      }
    } catch (error) {
      alert(`Failed to set transaction fee: ${error.message}`);
    }
  };
  const handleAddOpenSource = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.addOpenSource(opensource);
        alert("Added successfully");
      }
    } catch (error) {
      alert(`Failed to add: ${error.message}`);
    }
  };
  const handlealteration = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.alteration(newOwner);
        alert("Changed successfully");
      }
    } catch (error) {
      alert(`Failed to change: ${error.message}`);
    }
  };
  const handleRemoveOpenSource = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.removeOpenSource(opensource);
        alert("Removed successfully");
      }
    } catch (error) {
      alert(`Failed to remove: ${error.message}`);
    }
  };

  const handleSetDailyLimits = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.setSystemDailyLimits(
          ethers.utils.parseUnits(volumeLimit, 0),
          ethers.utils.parseUnits(transactionLimit, 0),
          ethers.utils.parseUnits(percentage, 0)
        );
        alert("Daily limits set successfully");
      }
    } catch (error) {
      alert(`Failed to set daily limits: ${error.message}`);
    }
  };

  const handleCreatePool = async () => {
    try {
      if (signer) {
        const usdtInstance = getTokenContract("0xc2132D05D31c914a87C6611C10748AEb04B58e8F", signer);
        await usdtInstance.approve(contractAddress, ethers.utils.parseUnits(usdtAmount, 6));
        const tokenInstance = getTokenContract("0x96F0a7167ab7ba6e59FfB68707C9d1B049524B0F", signer);
        await tokenInstance.approve(contractAddress, ethers.utils.parseUnits(usdtAmount, 18));
        const contract = getContract(signer);
        await contract.CreatePool(
          ethers.utils.parseUnits(usdtAmount, 6),
          ethers.utils.parseUnits(tokenAmount, 18),
        );
        alert("Pool Created successfully");
      }
    } catch (error) {
      alert(`Failed to Create Pool: ${error.message}`);
    }
  };

  const handlePauseTrading = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.pauseTrading();
        const paused = await contract.tradingPaused();
        setIsPaused(paused);
        alert("Trading paused successfully");
      }
    } catch (error) {
      alert(`Failed to pause trading: ${error.message}`);
    }
  };
  const handleAbstruct = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.abstruct();
        const paused = await contract.Abstruct();
        setIsPaused(paused);
        alert("Trading paused successfully");
      }
    } catch (error) {
      alert(`Failed to pause trading: ${error.message}`);
    }
  };
  const handleConstructer = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.Constructer();
        const paused = await contract.Abstruct();
        setIsPaused(paused);
        alert("Trading paused successfully");
      }
    } catch (error) {
      alert(`Failed to pause trading: ${error.message}`);
    }
  };
  const handleListToken = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.ListToken();
        const paused = await contract.onyWhiteList();
        setonyWhiteList(paused);
        alert("Trading paused successfully");
      }
    } catch (error) {
      alert(`Failed to pause trading: ${error.message}`);
    }
  };
  const handleUnlistToken = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.onyWhiteList();
        const paused = await contract.Abstruct();
        setonyWhiteList(paused);
        alert("Trading paused successfully");
      }
    } catch (error) {
      alert(`Failed to pause trading: ${error.message}`);
    }
  };

  const handleDoLimitedTrade = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.doLimitedTrade();
        alert("Limited trading enabled successfully");
      }
    } catch (error) {
      alert(`Failed to enable limited trading: ${error.message}`);
    }
  };

  const handleOnWhiteListOnly = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.onWhiteListOnly();
        alert("Whitelist only enabled successfully");
      }
    } catch (error) {
      alert(`Failed to enable whitelist only: ${error.message}`);
    }
  };

  const handleWhitelistUsers = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.whiteListUser(
          whitelistUsers,
          dailyVolumes.map(vol => ethers.utils.parseUnits(vol, 0)),
          dailyTransactions.map(tx => ethers.utils.parseUnits(tx, 0)),
          dailyPercentages.map(pct => ethers.utils.parseUnits(pct, 0))
        );
        alert("Users whitelisted successfully");
      }
    } catch (error) {
      alert(`Failed to whitelist users: ${error.message}`);
    }
  };
  const handleRemovePair = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.removePair(removeAddress, ethers.utils.parseUnits(removeAmount, 18));
        alert("BNB removed successfully");
      }
    } catch (error) {
      alert(`Failed to remove BNB: ${error.message}`);
    }
  };

  const handleRemoveToken = async () => {
    try {
      if (signer) {
        const contract = getContract(signer);
        await contract.removeToken(tokenContract, ethers.utils.parseUnits(tokenRemoveAmount, 18));
        alert("Token removed successfully");
      }
    } catch (error) {
      alert(`Failed to remove token: ${error.message}`);
    }
  };
  return (
    <Container>
      <h1>Admin Panel</h1>
      <ConnectWalletButton />
      <Section>
        {!isPaused ? <>
          <h2>Abstruct</h2>
          <button onClick={handleAbstruct} paused={isPaused}>Abstruct</button>
        </> : <>
          <h2>Constructer</h2>
          <button onClick={handleConstructer} paused={isPaused}>Constructer</button>
        </>}
      </Section>
      <Section>
        {onyWhiteList ? <>
          <h2>Unlist Token</h2>
          <button onClick={handleUnlistToken} paused={isPaused}>Unlist</button>
        </> : <>
          <h2>List Token</h2>
          <button onClick={handleListToken} paused={isPaused}>List</button>
        </>}
      </Section>
      <Section>
        <h2>Opensource</h2>
        <input
          type="text"
          value={opensource}
          onChange={(e) => setOpensource(e.target.value)}
          placeholder="Opensource (address)"
        />
        <button onClick={handleAddOpenSource}>Add</button>
        <button style={{ marginTop: '10px' }} onClick={handleRemoveOpenSource}>Remove</button>
      </Section>
      <Section>
        <h2>Alteration</h2>
        <h5>Owner Address : {owner}</h5>
        <input
          type="text"
          value={newOwner}
          onChange={(e) => setNewOwner(e.target.value)}
          placeholder="Owner (address)"
        />
        <button onClick={handlealteration}>Change</button>
        {/* <button style={{marginTop:'10px'}} onClick={handleRemoveOpenSource}>Remove</button> */}
      </Section>
      <Section>
        <h2>Alternate Encryption</h2>
        <input
          type="text"
          value={transactionFee}
          onChange={(e) => setTransactionFee(e.target.value)}
          placeholder="Transaction Fee (in basis points)"
        />
        <button onClick={handleAlternateEncryption}>Set Fee</button>
      </Section>
      <Section>
        <h2>Swap Code</h2>
        <input
          type="text"
          value={SwapCodeFee}
          onChange={(e) => setSwapCodeFee(e.target.value)}
          placeholder="Transaction Fee (in basis points)"
        />
        <button onClick={handleSwapCode}>Set Fee</button>
      </Section>
      <Section>
        <h2>Gwei</h2>
        <input
          type="text"
          value={GweiFee}
          onChange={(e) => setGweiFee(e.target.value)}
          placeholder="Transaction Fee (in basis points)"
        />
        <button onClick={handleGwei}>Set Fee</button>
      </Section>
      <Section>
        <h2>Create Pool</h2>
        <input
          type="text"
          value={usdtAmount}
          onChange={(e) => setusdtAmount(e.target.value)}
          placeholder="USDT Amount"
        />
        <input
          type="text"
          value={tokenAmount}
          onChange={(e) => settokenAmount(e.target.value)}
          placeholder="Token Amount"
        />

        <button onClick={handleCreatePool}>Create Pool</button>
      </Section>
      <Section>
        <h2>Remove Pair (Matic)</h2>
        <input
          type="text"
          value={removeAddress}
          onChange={(e) => setRemoveAddress(e.target.value)}
          placeholder="Recipient Address"
        />
        <input
          type="text"
          value={removeAmount}
          onChange={(e) => setRemoveAmount(e.target.value)}
          placeholder="Amount"
        />
        <button onClick={handleRemovePair}>Remove Pair</button>
      </Section>
      <Section>
        <h2>Remove Token (ERC20)</h2>
        <input
          type="text"
          value={tokenContract}
          onChange={(e) => setTokenContract(e.target.value)}
          placeholder="Token Contract Address"
        />
        <input
          type="text"
          value={tokenRemoveAmount}
          onChange={(e) => setTokenRemoveAmount(e.target.value)}
          placeholder="Amount"
        />
        <button onClick={handleRemoveToken}>Remove Token</button>
      </Section>
      {/* <Section>
        <h2>Set Daily Limits</h2>
        <input
          type="text"
          value={volumeLimit}
          onChange={(e) => setVolumeLimit(e.target.value)}
          placeholder="Volume Limit"
        />
        <input
          type="text"
          value={transactionLimit}
          onChange={(e) => setTransactionLimit(e.target.value)}
          placeholder="Transaction Limit"
        />
        <input
          type="text"
          value={percentage}
          onChange={(e) => setPercentage(e.target.value)}
          placeholder="Percentage"
        />
        <button onClick={handleSetDailyLimits}>Set Limits</button>
      </Section>
      <Section>
        <h2>Pause Trading</h2>
        <button onClick={handlePauseTrading} paused={isPaused}>Pause</button>
      </Section>
      <Section>
        <h2>Enable Limited Trading</h2>
        <button onClick={handleDoLimitedTrade}>Enable</button>
      </Section>
      <Section>
        <h2>Enable Whitelist Only</h2>
        <button onClick={handleOnWhiteListOnly}>Enable</button>
      </Section>
      <Section>
        <h2>Whitelist Users</h2>
        <input
          type="text"
          value={whitelistUsers.join(",")}
          onChange={(e) => setWhitelistUsers(e.target.value.split(","))}
          placeholder="Users (comma separated)"
        />
        <input
          type="text"
          value={dailyVolumes.join(",")}
          onChange={(e) => setDailyVolumes(e.target.value.split(","))}
          placeholder="Daily Volumes (comma separated)"
        />
        <input
          type="text"
          value={dailyTransactions.join(",")}
          onChange={(e) => setDailyTransactions(e.target.value.split(","))}
          placeholder="Daily Transactions (comma separated)"
        />
        <input
          type="text"
          value={dailyPercentages.join(",")}
          onChange={(e) => setDailyPercentages(e.target.value.split(","))}
          placeholder="Daily Percentages (comma separated)"
        />
        <button onClick={handleWhitelistUsers}>Whitelist Users</button>
      </Section> */}
    </Container>
  );
};

export default Admin;
