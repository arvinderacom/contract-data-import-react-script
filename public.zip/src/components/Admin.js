// src/components/Admin.js
import React, { useState } from "react";
import { useWeb3 } from "../contexts/Web3Context";
import { getContract } from "../contract";
import styled from "styled-components";
import ConnectWalletButton from "./ConnectWalletButton";
import { ethers, providers } from 'ethers'; 

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  border-radius: 10px;
  background-color: #f9f9f9;
`;

const Section = styled.div`
  margin: 20px 0;
  width: 100%;

  h2 {
    margin-bottom: 10px;
  }

  input {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }

  button {
    width: 100%;
    padding: 10px;
    background-color: #4caf50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;

    &:hover {
      background-color: #45a049;
    }
  }
`;

const Admin = () => {
  const { signer } = useWeb3();
  const [transactionFee, setTransactionFee] = useState("");
  const [volumeLimit, setVolumeLimit] = useState("");
  const [transactionLimit, setTransactionLimit] = useState("");
  const [percentage, setPercentage] = useState("");

  const handleSetTransactionFee = async () => {
    if (signer) {
      const contract = getContract(signer);
      await contract.setTransactionFee(ethers.utils.parseUnits(transactionFee, 0));
    }
  };

  const handleSetDailyLimits = async () => {
    if (signer) {
      const contract = getContract(signer);
      await contract.setSystemDailyLimits(
        ethers.utils.parseUnits(volumeLimit, 0),
        ethers.utils.parseUnits(transactionLimit, 0),
        ethers.utils.parseUnits(percentage, 0)
      );
    }
  };

  const handlePauseTrading = async () => {
    if (signer) {
      const contract = getContract(signer);
      await contract.pauseTrading();
    }
  };

  const handleDoLimitedTrade = async () => {
    if (signer) {
      const contract = getContract(signer);
      await contract.doLimitedTrade();
    }
  };

  const handleOnWhiteListOnly = async () => {
    if (signer) {
      const contract = getContract(signer);
      await contract.onWhiteListOnly();
    }
  };

  return (
    <Container>
      <h1>Admin Panel</h1>
      <ConnectWalletButton />
      <Section>
        <h2>Set Transaction Fee</h2>
        <input
          type="text"
          value={transactionFee}
          onChange={(e) => setTransactionFee(e.target.value)}
          placeholder="Transaction Fee (in basis points)"
        />
        <button onClick={handleSetTransactionFee}>Set Fee</button>
      </Section>
      <Section>
        <h2>Set Daily Limits</h2>
        <input
          type="text"
          value={volumeLimit}
          onChange={(e) => setVolumeLimit(e.target.value)}
          placeholder="Volume Limit"
        />
        <input
          type="text"
          value={transactionLimit}
          onChange={(e) => setTransactionLimit(e.target.value)}
          placeholder="Transaction Limit"
        />
        <input
          type="text"
          value={percentage}
          onChange={(e) => setPercentage(e.target.value)}
          placeholder="Percentage"
        />
        <button onClick={handleSetDailyLimits}>Set Limits</button>
      </Section>
      <Section>
        <h2>Pause Trading</h2>
        <button onClick={handlePauseTrading}>Pause</button>
      </Section>
      <Section>
        <h2>Enable Limited Trading</h2>
        <button onClick={handleDoLimitedTrade}>Enable</button>
      </Section>
      <Section>
        <h2>Enable Whitelist Only</h2>
        <button onClick={handleOnWhiteListOnly}>Enable</button>
      </Section>
    </Container>
  );
};

export default Admin;
