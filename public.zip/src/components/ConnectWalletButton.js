// src/components/ConnectWalletButton.js
import React from "react";
import { useWeb3 } from "../contexts/Web3Context";
import styled from "styled-components";

const Button = styled.button`
  background-color: #4caf50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  margin: 10px;

  &:hover {
    background-color: #45a049;
  }
`;

const ConnectWalletButton = () => {
  const { connectWallet, account } = useWeb3();

  return (
    <Button onClick={connectWallet}>
      {account ? `Connected: ${account.substring(0, 6)}...${account.substring(account.length - 4)}` : "Connect Wallet"}
    </Button>
  );
};

export default ConnectWalletButton;
